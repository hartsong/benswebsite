function Rocks() {
    const Img = document.querySelector('img');
    Img.src = 'Rocks.JPG';
    Img.alt = 'Rocks';
}

function Wood() {
    const Img = document.querySelector('img');
    Img.src = 'Wood.JPG';
    Img.alt = 'Wood';
}

function Cloth(){
    const Img = document.querySelector('img');
    Img.src = 'Cloth.JPG';
    Img.alt = 'Cloth';

}